const {createRequire}=require('node:module');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {chromium}=createRequire('/workspace/codex-/package.json')('@playwright/test');
const out='/workspace/work/aura-remake-preview';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
 const errors=[], checks=[], visual=[];
 const check=(name,value)=>{assert.ok(value,name);checks.push(name)};
 const boot=async(viewport,dpr=1)=>{
  const page=await browser.newPage({viewport,deviceScaleFactor:dpr});
  page.on('pageerror',e=>errors.push(e.stack||e.message));
  await page.goto('http://127.0.0.1:4173/?qa=1&vfx-preview=1',{waitUntil:'networkidle'});
  await page.locator('.vfx-controls').waitFor();
  await page.evaluate(()=>window.__BLADE__.game.scene.getScene('weapon-vfx-preview').scene.pause());
  return page;
 };
 const step=async(page,n)=>page.evaluate(n=>{const s=window.__BLADE__.game.scene.getScene('weapon-vfx-preview');for(let i=0;i<n;i++)s.update(0,1000/60);return s.vfx.diagnostics},n);
 const pixels=async page=>{await page.waitForTimeout(40);return page.evaluate(()=>{
   const s=window.__BLADE__.game.scene.getScene('weapon-vfx-preview'),c=s.game.canvas,b=s.vfx.WeaponSprite.getBounds(),d=c.width/c.clientWidth;
   const x=Math.max(0,Math.floor((b.x-30)*d)),y=Math.max(0,Math.floor((b.y-35)*d));
   const w=Math.min(c.width-x,Math.ceil((b.width+70)*d)),h=Math.min(c.height-y,Math.ceil((b.height+70)*d));
   return Array.from(c.getContext('2d').getImageData(x,y,w,h).data);
 })};
 const diff=(a,b)=>{assert.equal(a.length,b.length);let n=0;for(let i=0;i<a.length;i+=4)if(Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2])>12)n++;return n};
 const desktop=await boot({width:1100,height:800});
 await desktop.locator('[data-vfx="base-art"]').check();
 const summary=[];
 for(const [element,period] of [['fire',1.2],['ice',1.8],['poison',2],['lightning',1.6]]){
  await desktop.locator('[data-vfx="element"]').selectOption(element);await desktop.locator('[data-vfx="clear"]').click();
  const start=await step(desktop,1),half=await step(desktop,Math.round(period*30)),cycle=await step(desktop,Math.round(period*30));
  check(element+' breathing period',Math.abs(start.pulses[element]-cycle.pulses[element])<.001&&half.pulses[element]>start.pulses[element]+.1);
  const a=await pixels(desktop);await step(desktop,11);const b=await pixels(desktop),changed=diff(a,b);
  check(element+' changes actual canvas pixels with base sword art',changed>12);
  await desktop.screenshot({path:out+'/'+element+'-base-idle.png'});
  await desktop.locator('[data-vfx="attack"]').click();const attack=await step(desktop,13);
  check(element+' attack produces actual trail',attack.state==='attack'&&attack.counts.trail>0);
  await step(desktop,60);
  await desktop.locator('[data-vfx="hit"]').click();const hit=await step(desktop,3);
  check(element+' hit uses element renderer',hit.state==='hit'&&hit.hitElements.includes(element));
  const settled=await step(desktop,150);check(element+' effects expire',settled.counts.hits===0&&settled.counts.trail===0);
  check(element+' opaque weapon body retained',settled.weaponAlpha===1);
  if(element==='lightning')check('lightning sampled lifetimes 0.05–0.15 seconds',settled.boltLifetimes.length>8&&settled.boltLifetimes.every(t=>t>=.05&&t<=.15));
  await desktop.locator('[data-vfx="clear"]').click();await desktop.locator('[data-vfx="motion"]').uncheck();await step(desktop,1);
  const frozenA=await pixels(desktop);await step(desktop,35);const frozenB=await pixels(desktop);
  check(element+' reduced motion is visually stationary',diff(frozenA,frozenB)===0);
  await desktop.locator('[data-vfx="motion"]').check();await desktop.locator('[data-vfx="clear"]').click();
  await step(desktop,25);const full=await step(desktop,1);
  await desktop.locator('[data-vfx="quality"]').check();await step(desktop,25);const low=await step(desktop,1);
  check(element+' simplified mode reduces active effects',low.counts.total<full.counts.total);
  await desktop.locator('[data-vfx="quality"]').uncheck();
  summary.push({element,period,changedPixels:changed,full:full.counts.total,simplified:low.counts.total,boltLifetimes:settled.boltLifetimes});
 }
 const mobile=await boot({width:390,height:844},2);
 for(const element of ['fire','ice','poison','lightning']){
  await mobile.locator('[data-vfx="element"]').selectOption(element);
  await mobile.locator('[data-vfx="size"]').fill('0.5');await step(mobile,28);
  await mobile.screenshot({path:out+'/mobile-'+element+'.png'});
  const bounds=await mobile.locator('[data-vfx="attack"]').boundingBox();
  check('mobile '+element+' attack touch target',bounds&&bounds.height>=44&&bounds.x>=0&&bounds.x+bounds.width<=390);
  await mobile.locator('[data-vfx="attack"]').click();const attack=await step(mobile,13);
  check('mobile '+element+' active trail',attack.counts.trail>0);
 }
 for(const form of ['greatsword','dual','wave']){
  await mobile.locator('[data-vfx="form"]').selectOption(form);const s=await step(mobile,20);
  check('mobile form '+form+' renders body',s.weaponAlpha===1);
 }
 for(const preset of ['calamity','stormFirePoison']){
  await desktop.locator('[data-vfx="element"]').selectOption(preset);const s=await step(desktop,30);
  check(preset+' keeps three independent elements',s.active.length===3&&s.counts.elemental.fire>0&&s.counts.elemental.poison>0);
 }
 await desktop.locator('[data-vfx="exit"]').click();await desktop.locator('.weapon-vfx-preview').waitFor({state:'detached'});
 await desktop.locator('[data-action="vfx-preview"]').click();await desktop.locator('.vfx-controls').waitFor();
 check('preview can reopen without duplicate DOM',await desktop.locator('.weapon-vfx-preview').count()===1);
 check('preview did not create a battle run',await desktop.evaluate(()=>window.__BLADE__.run===undefined));
 check('no browser runtime errors',errors.length===0);
 fs.writeFileSync(out+'/verification.json',JSON.stringify({checks,summary,errors,scope:'Independent VFX preview only; no gameplay playthrough or existing test suite.'},null,2));
 console.log(JSON.stringify({passed:checks.length,summary,errors}));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
